# MARKETING FIELDNOTES｜數位行銷知識庫

以 HTML、CSS、原生 JavaScript 和 JSON 製作的繁體中文教學網站。風格為專業編輯式設計，可透過 `AGENTS.md` 指導 AI 快速增加文章。

## 功能
- 首頁可依分類瀏覽、即時搜尋文章與內容關鍵字
- 每篇文章有獨立可分享的網址：`article.html?id=文章ID`
- 文章內含目錄、分段教學、重點整理、下一篇連結
- 響應式設計，無需框架、後端或 API key

## 專案結構
見 [AGENTS.md](./AGENTS.md) 第 3 節。

## 本機預覽
在專案根目錄執行：
```bash
python -m http.server 8000
```
打開 http://localhost:8000/ ，不可直接雙擊 HTML（瀏覽器可能阻擋 `fetch` 讀取 JSON）。

## 新增文章
1. 先讓 AI 閱讀 `AGENTS.md`。
2. 按照第 6 節模板，在 `data/notes.json` 新增一個物件，保留既有資料。
3. 執行 `python -m json.tool data/notes.json > /dev/null` 確認 JSON 語法正確。
4. 預覽首頁與 `article.html?id=新文章ID`。**不必建立新 HTML 頁面或複製卡片。**

可對 AI 下指令：「請先讀 AGENTS.md，幫我新增『如何規劃短影片內容』教學，保持原設計，不修改其他文章，完成後檢查 JSON 與連結。」

## 發布到 GitHub Pages
1. 在 GitHub 建立 **Public** Repository，名稱可為 `marketing-notes-site`。
2. 上傳**解壓縮後的檔案本身**至 Repository 根目錄（不是整包 ZIP），確保 `index.html` 位在根目錄。
3. 進入 **Settings → Pages**，在 **Build and deployment** 選擇 **Deploy from a branch**。
4. Branch 選 `main`，資料夾選 `/(root)`，按 Save。
5. 等待 GitHub 顯示部署完成，網址一般為 `https://你的帳號.github.io/marketing-notes-site/`。
6. 實際測試首頁、分類、搜尋與文章頁。

## 作業理念
本專案不只產生一個靜態頁面，而是建立「固定資料格式 + 共用渲染模板 + AI 開發規則」的內容系統；後續新增文章時，AI 只要遵守 `AGENTS.md` 並更新 `data/notes.json` 就能直接擴充。

> 本專案尚未替使用者上傳 GitHub；請自行發布並驗證公開網址。
